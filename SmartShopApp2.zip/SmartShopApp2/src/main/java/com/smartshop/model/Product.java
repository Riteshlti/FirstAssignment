package com.smartshop.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Product {

	public Product() {
		super();
	}


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long productID;

	@Column(name = "productname", nullable= false)
	private String productName;

	@Column(name = "category", nullable = false)
	private String category;

	@Column(name = "quantity", nullable = false)
	private int quantity;

	@Column(name = "unitprice", nullable = false)
	private long unitPrice;

	@Column(name = "totalprice", nullable = false)
	private long totalPrice;

	@Column(name = "rating", nullable = false)
	private int rating;

	public long getProductID() {
		return productID;
	}

	public void setProductID(long productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public long getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(long unitPrice) {
		this.unitPrice = unitPrice;
	}

	public long getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(long totalPrice) {
		this.totalPrice = totalPrice;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public Product(long productID, String productName, String category, int quantity, long unitPrice, long totalPrice,
			int rating) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.category = category;
		this.quantity = quantity;
		this.unitPrice = unitPrice;
		this.totalPrice = totalPrice;
		this.rating = rating;
	}
	
	

	
	  @Override public String toString() { return "Product [productID=" + productID
	  + ", productName=" + productName + ", category=" + category + ", quantity=" +
	  quantity + ", unitPrice=" + unitPrice + ", totalPrice=" + totalPrice +
	  ", rating=" + rating + "]"; }
	  
	 

}
