package com.smartshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.smartshop.model.Product;
import com.smartshop.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/products")
	public List<Product> getAllProductDetails() {
		return productService.getAllProducts(); // response entity as list of json
	}
	
	@PostMapping("/products/filter")
	public Product saveEmployee(@RequestBody Product prod)
	{
	return productService.saveProd(prod);
	}
	
	@GetMapping("/products/filterByName")
	public List<Product> getProductByName(@RequestParam String name){
		return productService.getProductsByName(name);
	}
	 

}
