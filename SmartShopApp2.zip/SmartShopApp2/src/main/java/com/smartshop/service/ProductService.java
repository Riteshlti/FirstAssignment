package com.smartshop.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.smartshop.dao.ProductRepository;
import com.smartshop.model.Product;

@Service
public class ProductService {

	@Autowired
	ProductRepository prepo;
	
	public List<Product> getAllProducts() {
		return prepo.findAll();
	}
	
	public Product saveProd(Product prod){
		return prepo.save(prod);
		}
	
	public List<Product> getProductsByName(String name) {
		return prepo.findByproductName(name);
		}
	
		 
}
